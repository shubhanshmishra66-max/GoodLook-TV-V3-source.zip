# GoodLook TV V3

A lightweight Android TV dashboard written in Kotlin.

## Features
- TV-friendly dashboard with D-pad focus support
- Basic device information
- Internal storage overview
- Network connection diagnostics
- Launcher app browser and app launching
- Android system settings shortcut

## Build
Use Android Gradle Plugin 8.7.3, Kotlin 2.0.21 and JDK 17.
Run `gradle assembleDebug` from the project root.
APK output: `app/build/outputs/apk/debug/app-debug.apk`.

Some device and network information is restricted by Android or the TV manufacturer.
