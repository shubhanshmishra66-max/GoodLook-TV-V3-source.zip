package com.goodlook.tv

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.pm.PackageManager
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 16, 30)
    private val panel = Color.rgb(22, 32, 52)
    private val accent = Color.rgb(65, 170, 255)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun text(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

    private fun base(title: String, subtitle: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(28), dp(22), dp(28), dp(22))
        }
        root.addView(text("GOODLOOK TV  /  V3", 13f, accent, true))
        root.addView(text(title, 30f, Color.WHITE, true))
        root.addView(text(subtitle, 14f, Color.LTGRAY))
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(14), 0, dp(24))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun card(title: String, detail: String, action: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel)
            setPadding(dp(18), dp(12), dp(18), dp(12))
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener { action() }
            setOnFocusChangeListener { v, focused ->
                v.background = rounded(if (focused) Color.rgb(34, 65, 96) else panel)
            }
        }
        box.addView(text(title, 19f, Color.WHITE, true))
        box.addView(text(detail, 13f, Color.LTGRAY))
        val lp = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(12)
        content.addView(box, lp)
    }

    private fun showHome() {
        base("Your TV. Clearly.", "A simple control centre for your Android TV.")
        card("Device information", "Model, Android version and hardware", ::showDevice)
        card("Storage manager", "Check used and available storage", ::showStorage)
        card("Network diagnostics", "Wi-Fi and network connection details", ::showNetwork)
        card("App manager", "Browse and open installed launcher apps", ::showApps)
        card("System settings", "Open supported Android settings pages") {
            openSettings(Settings.ACTION_SETTINGS)
        }
        card("About GoodLook TV", "Version 3.0.0") { showAbout() }
        content.addView(text("Use your TV remote's D-pad and OK button to navigate.", 12f, Color.GRAY))
        content.getChildAt(0)?.requestFocus()
    }

    private fun backCard() = card("← Back to dashboard", "Return to the main screen", ::showHome)

    private fun showDevice() {
        base("Device information", "Basic details reported by Android")
        val details = listOf(
            "Device" to android.os.Build.DEVICE,
            "Model" to android.os.Build.MODEL,
            "Manufacturer" to android.os.Build.MANUFACTURER,
            "Brand" to android.os.Build.BRAND,
            "Android version" to android.os.Build.VERSION.RELEASE,
            "SDK level" to android.os.Build.VERSION.SDK_INT.toString(),
            "Build" to android.os.Build.DISPLAY,
            "App version" to "3.0.0"
        )
        details.forEach { (k, v) -> infoCard(k, v.ifBlank { "Not reported" }) }
        backCard()
    }

    private fun showStorage() {
        base("Storage manager", "Approximate device storage information")
        try {
            val stat = StatFs(android.os.Environment.getDataDirectory().path)
            val total = stat.totalBytes
            val free = stat.availableBytes
            val used = (total - free).coerceAtLeast(0)
            infoCard("Total storage", formatBytes(total))
            infoCard("Used storage", formatBytes(used))
            infoCard("Available storage", formatBytes(free))
            infoCard("Usage", if (total > 0) "${(used * 100 / total)}%" else "Not available")
        } catch (_: Exception) {
            infoCard("Storage", "Android did not provide storage details.")
        }
        backCard()
    }

    private fun showNetwork() {
        base("Network diagnostics", "Connection details available to this app")
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val caps = network?.let { cm.getNetworkCapabilities(it) }
        val connected = caps != null
        infoCard("Status", if (connected) "Connected" else "Not connected")
        infoCard("Transport", when {
            caps?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi-Fi"
            caps?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"
            caps?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Cellular"
            connected -> "Other"
            else -> "Unavailable"
        })
        infoCard("Internet capability", if (caps?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) == true) "Available" else "Not reported")
        infoCard("Wi-Fi name / IP", "Android may restrict these details on some TV devices.")
        backCard()
    }

    private fun showApps() {
        base("App manager", "Apps with a launcher icon on this TV")
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }

        if (apps.isEmpty()) {
            infoCard("No apps found", "Android did not return launcher apps.")
        } else {
            apps.forEach { resolved ->
                val label = resolved.loadLabel(packageManager).toString()
                val pkg = resolved.activityInfo.packageName
                card(label, pkg) {
                    val launch = packageManager.getLaunchIntentForPackage(pkg)
                    if (launch != null) {
                        try { startActivity(launch) }
                        catch (_: Exception) { message("Unable to open $label on this device.") }
                    } else {
                        message("No launch action is available for $label.")
                    }
                }
            }
        }
        backCard()
    }

    private fun showAbout() {
        base("About", "GoodLook TV V3")
        infoCard("Version", "3.0.0")
        infoCard("Purpose", "A lightweight Android TV utility dashboard.")
        infoCard("Compatibility", "Designed for Android TV. Some information depends on device permissions and manufacturer support.")
        backCard()
    }

    private fun infoCard(label: String, value: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            addView(text(label.uppercase(Locale.getDefault()), 11f, accent, true))
            addView(text(value, 17f, Color.WHITE))
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(9)
        content.addView(box, lp)
    }

    private fun openSettings(action: String) {
        try { startActivity(Intent(action)) }
        catch (_: Exception) { message("This settings page is not available on this TV.") }
    }

    private fun message(value: String) {
        AlertDialog.Builder(this).setMessage(value).setPositiveButton("OK", null).show()
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var size = bytes.toDouble()
        var index = 0
        while (size >= 1024 && index < units.lastIndex) {
            size /= 1024
            index++
        }
        return String.format(Locale.getDefault(), "%.1f %s", size, units[index])
    }
}
